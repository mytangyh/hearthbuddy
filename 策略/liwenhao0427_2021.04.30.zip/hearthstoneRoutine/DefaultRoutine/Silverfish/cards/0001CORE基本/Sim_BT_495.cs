using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_495 : SimTemplate //* 刃缚精锐 Glaivebound Adept
	{
		//<b>Battlecry:</b> If your hero attacked this turn,deal 4 damage.
		//<b>战吼：</b>在本回合中，如果你的英雄进行过攻击，则造成4点伤害。
		
		
	}
}
