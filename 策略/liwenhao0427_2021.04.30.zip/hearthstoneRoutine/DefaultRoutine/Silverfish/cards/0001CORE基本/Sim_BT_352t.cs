using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_352t : SimTemplate //* 伊利达雷萨特 Illidari Satyr
	{
		//
		//
		
		
	}
}
