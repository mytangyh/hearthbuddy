using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NEW1_034 : SimTemplate //* 霍弗 Huffer
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
