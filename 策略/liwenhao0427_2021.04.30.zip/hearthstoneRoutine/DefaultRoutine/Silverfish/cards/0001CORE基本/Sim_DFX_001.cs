using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DFX_001 : SimTemplate //* Fast Spawn to Deck Dummy FX Fast Spawn to Deck Dummy FX
	{
		//Holds the FX for inserting a card into a deck quickly.
		//Holds the FX for inserting a card into a deck quickly.
		
		
	}
}
