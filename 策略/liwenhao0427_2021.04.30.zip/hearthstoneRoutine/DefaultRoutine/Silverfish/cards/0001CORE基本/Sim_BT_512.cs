using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_512 : SimTemplate //* 心中的恶魔 Inner Demon
	{
		//Give your hero +8_Attack this turn.
		//在本回合中，使你的英雄获得+8攻击力。
		
		
	}
}
