using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_021 : SimTemplate //* 爆裂末日 Crackling Doom
	{
		//Deal $12 damage to all_minions.<b>Overload</b>: (10)
		//对所有随从造成$12点伤害。<b>过载：</b>（10）
		
		
	}
}
