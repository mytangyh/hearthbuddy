using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS1_130_Puzzle : SimTemplate //* 神圣惩击 Holy Smite
	{
		//Deal $2 damage.
		//造成$2点伤害。
		
		
	}
}
