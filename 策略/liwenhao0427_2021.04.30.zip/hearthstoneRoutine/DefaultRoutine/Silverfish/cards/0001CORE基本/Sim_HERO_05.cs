using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_HERO_05 : SimTemplate //rexxar
	{

//
		

	}
}