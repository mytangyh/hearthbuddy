using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_026 : SimTemplate //* 炽炎长剑 Blazing Longsword
	{
		//Also damages minions next to whomever your hero attacks.
		//同时对其攻击目标相邻的随从造成伤害。
		
		
	}
}
