using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_024 : SimTemplate //* 疯魔药水 Bottled Madness
	{
		//Replace your hand with random Demons.
		//随机将你的手牌替换成恶魔牌。
		
		
	}
}
