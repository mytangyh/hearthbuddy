using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_213 : SimTemplate //* 鲁莽火箭兵 Reckless Rocketeer
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
