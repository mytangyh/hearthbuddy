using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_921 : SimTemplate //* 奥达奇战刃 Aldrachi Warblades
	{
		//<b>Lifesteal</b>
		//<b>吸血</b>
		
		
	}
}
