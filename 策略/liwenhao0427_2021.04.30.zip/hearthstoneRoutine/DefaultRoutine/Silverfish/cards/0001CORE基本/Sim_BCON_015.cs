using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BCON_015 : SimTemplate //* 慷慨大方 Generous Spirit
	{
		//[x]Choose a friendly minion.Give it to your opponentand draw 3 cards.
		//选择一个友方随从，交给你的对手，并抽三张牌。
		
		
	}
}
