using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_051 : SimTemplate //* 石爪图腾 Stoneclaw Totem
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
