using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BT_740 : SimTemplate //* 灵魂裂劈 Soul Cleave
	{
		//<b>Lifesteal</b>Deal $2 damage to two random enemy minions.
		//<b>吸血</b>随机对两个敌方随从造成$2点伤害。
		
		
	}
}
