using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_131 : SimTemplate //* 暴风城骑士 Stormwind Knight
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
