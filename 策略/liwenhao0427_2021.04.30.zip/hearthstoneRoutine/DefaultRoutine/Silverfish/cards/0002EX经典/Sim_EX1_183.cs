using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_183 : SimTemplate //* 野性赐福 Gift of the Wild
	{
		//Give your minions +2/+2 and <b>Taunt</b>.
		//使你的所有随从获得+2/+2和<b>嘲讽</b>。
		
		
	}
}
