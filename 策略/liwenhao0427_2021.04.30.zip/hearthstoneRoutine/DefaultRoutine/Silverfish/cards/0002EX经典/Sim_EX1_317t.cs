using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_317t : SimTemplate //* 游荡小鬼 Worthless Imp
	{
		//<i>You are out of demons! At least there are always imps...</i>
		//<i>你的恶魔用完了！但至少...还有小鬼。</i>
		
		
	}
}
