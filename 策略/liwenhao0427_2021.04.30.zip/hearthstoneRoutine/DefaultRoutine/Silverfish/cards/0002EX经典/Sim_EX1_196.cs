using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_196 : SimTemplate //* 血色征服者 Scarlet Subjugator
	{
		//<b>Battlecry:</b> Give an enemy minion -2 Attack until your_next turn.
		//<b>战吼：</b>直到你的下个回合，使一个敌方随从获得-2攻击力。
		
		
	}
}
