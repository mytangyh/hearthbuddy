using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_165t1 : SimTemplate //* 利爪德鲁伊 Druid of the Claw
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
