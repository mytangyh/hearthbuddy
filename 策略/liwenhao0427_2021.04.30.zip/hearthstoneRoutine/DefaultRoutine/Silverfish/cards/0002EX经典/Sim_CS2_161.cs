using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_161 : SimTemplate //* 拉文霍德刺客 Ravenholdt Assassin
	{
		//<b>Stealth</b>
		//<b>潜行</b>
		
		
	}
}
