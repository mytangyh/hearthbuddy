using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_543 : SimTemplate //* 暴龙王克鲁什 King Krush
	{
		//<b>Charge</b>
		//<b>冲锋</b>
		
		
	}
}
