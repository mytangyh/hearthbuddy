using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_021 : SimTemplate //* 萨尔玛先知 Thrallmar Farseer
	{
		//<b>Windfury</b>
		//<b>风怒</b>
		
		
	}
}
