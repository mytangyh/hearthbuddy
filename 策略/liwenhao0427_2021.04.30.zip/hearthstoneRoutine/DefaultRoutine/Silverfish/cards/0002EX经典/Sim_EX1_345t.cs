using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_345t : SimTemplate //* 空无之影 Shadow of Nothing
	{
		//Mindgames whiffed! Your opponent had no minions!
		//控心术无效！你对手的牌库中没有随从牌了！
		
		
	}
}
