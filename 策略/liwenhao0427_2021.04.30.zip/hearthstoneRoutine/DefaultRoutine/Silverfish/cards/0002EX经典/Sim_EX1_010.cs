using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_010 : SimTemplate //* 狼人渗透者 Worgen Infiltrator
	{
		//<b>Stealth</b>
		//<b>潜行</b>
		
		
	}
}
