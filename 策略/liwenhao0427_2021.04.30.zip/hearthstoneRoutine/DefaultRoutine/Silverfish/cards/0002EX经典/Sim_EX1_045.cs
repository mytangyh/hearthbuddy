using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_045 : SimTemplate //* 上古看守者 Ancient Watcher
	{
		//Can't attack.
		//无法攻击。
		
		
	}
}
