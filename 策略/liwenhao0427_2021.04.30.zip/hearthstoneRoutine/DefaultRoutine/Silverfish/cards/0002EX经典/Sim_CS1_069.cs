using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS1_069 : SimTemplate //* 沼泽爬行者 Fen Creeper
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
