using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_405 : SimTemplate //* 持盾卫士 Shieldbearer
	{
		//<b>Taunt</b>
		//<b>嘲讽</b>
		
		
	}
}
