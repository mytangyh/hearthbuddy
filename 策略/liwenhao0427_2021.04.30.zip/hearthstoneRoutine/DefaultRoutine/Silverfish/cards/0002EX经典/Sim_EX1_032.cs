using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_032 : SimTemplate //* 烈日行者 Sunwalker
	{
		//<b>Taunt</b><b>Divine Shield</b>
		//<b>嘲讽</b><b>圣盾</b>
		
		
	}
}
