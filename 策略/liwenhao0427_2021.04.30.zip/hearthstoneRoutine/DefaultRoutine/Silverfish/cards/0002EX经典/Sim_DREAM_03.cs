using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_DREAM_03 : SimTemplate //* 翡翠幼龙 Emerald Drake
	{
		//
		//
		
		
	}
}
